from distutils.core import setup

setup(
    name='K911PythonAlertsServer',
    version='0.1',
    packages=['k911-python-alerts-server',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.txt').read(),
)
